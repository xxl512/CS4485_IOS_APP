//
//  ViewController.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 2/28/22.
//



import UIKit


class ViewController: UIViewController{
    


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.


        }
        
    @IBAction func segueButtonPressedC(_ sender: Any) {
        performSegue(withIdentifier: "goToChartStoryboard", sender: self)
    }
    
    @IBAction func segueButtonPressedC1(_ sender: Any) {
        performSegue(withIdentifier: "goToChart1Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedC2(_ sender: Any) {
        performSegue(withIdentifier: "goToChart2Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedC3(_ sender: Any) {
        performSegue(withIdentifier: "goToChart3Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedC4(_ sender: Any) {
        performSegue(withIdentifier: "goToChart4Storyboard", sender: self)
    }
    
    
    
    @IBAction func segueButtonPressedM(_ sender: Any) {
        performSegue(withIdentifier: "goToMoistureStoryboard", sender: self)
    }
    
    
    @IBAction func segueButtonPressedM1(_ sender: Any) {
        performSegue(withIdentifier: "goToMoisture1Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedM2(_ sender: Any) {
        performSegue(withIdentifier: "goToMoisture2Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedM3(_ sender: Any) {
        performSegue(withIdentifier: "goToMoisture3Storyboard", sender: self)
    }
    
    @IBAction func segueButtonPressedM4(_ sender: Any) {
        performSegue(withIdentifier: "goToMoisture4Storyboard", sender: self)
    }
    
    
    
    
    @IBAction func segueButtonPressedQS(_ sender: Any) {
        performSegue(withIdentifier: "goToChart1QuickSightStoryboard", sender: self)
    }
    
 
    
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToChartStoryboard" {
            guard let vc = segue.destination as? ChartViewController else { return }
            vc.segueText = "This is the chart page"
            vc.viewDidLoad()
            
        }
    }
     
     */
}




//
//  MData.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 4/23/22.
//

import Foundation


struct MData: Codable{
    var Time: Int?
    var Room: String?
    var Prediction: Double?
    
    var PredictionString: String {
        return String(format: "%.5f", Prediction!)
    }

}

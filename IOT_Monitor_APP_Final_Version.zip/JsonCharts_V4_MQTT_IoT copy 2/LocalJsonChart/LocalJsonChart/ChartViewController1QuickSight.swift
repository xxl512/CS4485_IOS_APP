//
//  ChartViewController1QuickSight.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 4/22/22.
//

import UIKit
import WebKit
class CharViewController1QuickSight: UIViewController{
    
    let webView = WKWebView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(webView)
        guard let url = URL(string: "https://us-west-2.quicksight.aws.amazon.com/sn/accounts/963854468303/dashboards/f72b23a2-0b7c-4f72-8fe2-10c6a53131de?directory_alias=iotteam") else {
            return
        }
        webView.load(URLRequest(url: url))
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }
    
    
    
}

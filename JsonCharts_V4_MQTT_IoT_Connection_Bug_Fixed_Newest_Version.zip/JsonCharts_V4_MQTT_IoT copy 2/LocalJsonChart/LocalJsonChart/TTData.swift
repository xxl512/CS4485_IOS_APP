//
//  TTData.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 2/28/22.
//

import Foundation

struct TTData: Codable{
    let weatherData: [WeatherData]
}

struct WeatherData: Codable{
    let temperature: Double
    let time_per_hour: Int
    
    init(temperature: Double, time_per_hour: Int){
        self.temperature = temperature
        self.time_per_hour = time_per_hour
    }
}

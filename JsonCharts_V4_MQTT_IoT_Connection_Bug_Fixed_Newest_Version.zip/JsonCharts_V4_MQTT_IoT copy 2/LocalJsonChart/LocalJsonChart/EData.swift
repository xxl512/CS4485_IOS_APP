
import Foundation

struct EData: Codable{
    var Time: Int?
    var Room: String?
    var Temperature: Double?
    var Humidity: Double?
    var Pressure: Double?
    var Moisture: Double?

    
    var temperatureString: String {
        return String(format: "%.1f", Temperature!)
    }
    
    var moistureString: String {
        return String(format: "%.1f", Moisture!)
    }
}


//
//  ViewController.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 2/28/22.
//



import UIKit


class ViewController: UIViewController{
    


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.


        }
        
    @IBAction func segueButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "goToChartStoryboard", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToChartStoryboard" {
            guard let vc = segue.destination as? ChartViewController else { return }
            vc.segueText = "This is the chart page"
            vc.viewDidLoad()
            
        }
    }
}




//
//  ViewController.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 2/28/22.
//



import UIKit
import Charts
import TinyConstraints
import AWSIoT

class ChartViewController: UIViewController, ChartViewDelegate {
    
    @IBOutlet weak var newTextLabel: UILabel!
    
    var segueText: String = "Hi"
    
        lazy var lineChartView: LineChartView = {
 //   lazy var lineChartView: LineChartView = {
        let chartView = LineChartView()
        chartView.backgroundColor = .systemGreen
        
        chartView.rightAxis.enabled = false
        
        let yAxis = chartView.leftAxis
        yAxis.labelFont = .boldSystemFont(ofSize: 12)
        yAxis.setLabelCount(6, force: false)
        yAxis.labelTextColor = .white
        yAxis.axisLineColor = .white
        yAxis.labelPosition = .outsideChart
        
        chartView.xAxis.labelPosition = .bottom
        chartView.xAxis.labelFont = .boldSystemFont(ofSize: 12)
        chartView.xAxis.setLabelCount(6, force: false)
        chartView.xAxis.labelTextColor = .white
        chartView.xAxis.axisLineColor = .systemBrown
        
        chartView.animate(xAxisDuration: 2.5)
        
        
        
        return chartView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        if newTextLabel != nil {
            newTextLabel.text = segueText
        }else { return }
        
        if let localData = self.readLocalFile(forName: "envDataPart1") {
//            if let localData = self.readLocalFile(forName: "envDataSet") {
            let decodedData = self.parse(jsonData: localData)

            view.addSubview(lineChartView)
            lineChartView.centerInSuperview()
            lineChartView.width(to: view)
            lineChartView.heightToWidth(of: view)
             
            setData(et: decodedData!)
        }
        

    }
    
    private func readLocalFile(forName name: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: name, ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                print(jsonData)
                return jsonData
            }
        } catch {
            print(error)
        }
        
        return nil
    }
    
    private func parse(jsonData: Data) -> [EData]? {
        do {
            print("BEFOR PARSEING")
            let decodedData = try JSONDecoder().decode([EData].self,
                                                       from: jsonData)
            print("After PARSING")
            return decodedData
        } catch {
            print("decode error!!!!!!")
            return nil
        }
    }
        

    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        print(entry)
    }
    
    func setData(et: [EData]){
        // The dataEntry format is: ChartDataEntry(x: 0.0, y:10.0),
        var yValues: [ChartDataEntry] = []
        for weather in et {
            if (weather.temperature != nil){
                var wd = ChartDataEntry(x: Double(weather.timestamp!), y: weather.temperature!)
                yValues.append(wd)}
        }
        
        let set1 = LineChartDataSet(entries: yValues, label: "Time-Temperature read from local JSON File")
        
        set1.mode = .cubicBezier
        set1.drawCirclesEnabled = false
        set1.lineWidth = 3
        set1.setColor(.white)
        set1.fill = Fill(color: .white)
        set1.fillAlpha = 0.8
        set1.drawFilledEnabled = true
        
        set1.drawHorizontalHighlightIndicatorEnabled = false
        set1.highlightColor = .systemRed
        
        let data = LineChartData(dataSet: set1)
        
        data.setDrawValues(false)
        
        lineChartView.data = data
    }


}


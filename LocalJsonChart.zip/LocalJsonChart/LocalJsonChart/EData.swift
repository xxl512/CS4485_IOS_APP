//
//  EData.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 3/15/22.
//

import Foundation

//struct EData: Codable{
//     var envData: [EnvData]
//
//    init(from decoder: Decoder) throws {
//            var container = try decoder.unkeyedContainer()
//            envData = try container.decode([EnvData].self) // Decode just first element
//        }
//}

struct EData: Codable{
    var timestamp: Int?
    var precipitation: Double?
    var humidity: Double?
    var radiation: Double?
    var sunshine: Double?
    var pressure: Double?
    var temperature: Double?
    
//    {"timestamp":1535760000000,"precipitation":0.0,"humidity":95.6,"radiation":0.0,"sunshine":599.2,"pressure":1016.3,"temperature":16.1},
//
//    init(timestamp: Int, precipitation: Double, humidity: Double, radiation: Double, sunshine: Double, pressure: Double, temperature: Double){
//
//        self.timestamp = timestamp
//        self.precipitation = precipitation
//        self.humidity = humidity
//        self.radiation = radiation
//        self.sunshine = sunshine
//        self.pressure = pressure
//        self.temperature = temperature
//
//    }
//
//
    
}

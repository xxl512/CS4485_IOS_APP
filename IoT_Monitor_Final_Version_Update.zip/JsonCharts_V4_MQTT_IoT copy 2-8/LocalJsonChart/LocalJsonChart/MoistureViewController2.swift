//
//  MoistureViewController2.swift
//  LocalJsonChart
//
//  Created by Xiao Luo on 4/25/22.
//


import UIKit
import Charts
import TinyConstraints
import AWSIoT

class MoistureViewController2: UIViewController, ChartViewDelegate {

    @IBOutlet weak var roomLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var moistureLabel: UILabel!
    
    @IBAction func exit(_ sender: Any) {
        navigationController?.popViewController(animated: true)
         dataManager.unsubscribeTopic("esp32/pub")
        dataManager.disconnect()
        dismiss(animated: true, completion: nil)
        
    }
    // To store the live data entry
    var yValues: [ChartDataEntry] = []
    
    
    var dataManager: AWSIoTDataManager!
    
        lazy var lineChartView: LineChartView = {
 //   lazy var lineChartView: LineChartView = {
        let chartView = LineChartView()
        chartView.backgroundColor = .systemGreen
        
        chartView.rightAxis.enabled = false
        
        let yAxis = chartView.leftAxis
        yAxis.labelFont = .boldSystemFont(ofSize: 12)
        yAxis.setLabelCount(6, force: false)
        yAxis.labelTextColor = .white
        yAxis.axisLineColor = .white
        yAxis.labelPosition = .outsideChart
        
        chartView.xAxis.labelPosition = .bottom
        chartView.xAxis.labelFont = .boldSystemFont(ofSize: 12)
        chartView.xAxis.setLabelCount(6, force: false)
        chartView.xAxis.labelTextColor = .white
        chartView.xAxis.axisLineColor = .systemBrown
        
       // chartView.animate(xAxisDuration: 2.5)
        
        
        
        return chartView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view.
        
        // Create AWS credentials and configuration
        
        // This is Team's Credential
        let credentials = AWSCognitoCredentialsProvider(regionType:.USWest2, identityPoolId: "us-west-2:0ec8bfb0-1ce6-4499-82b3-a1658fd6ee76")
        
        let configuration = AWSServiceConfiguration(region:.USWest2, credentialsProvider: credentials)
        
        
        // Initialising AWS IoT And IoT DataManager
        AWSIoT.register(with: configuration!, forKey: "kAWSIoT")  // Same configuration var as above
        
        // This is Team's Endpoint
        let iotEndPoint = AWSEndpoint(urlString: "wss://a31fy3n3mv508f-ats.iot.us-west-2.amazonaws.com/mqtt") // Access
      
        //Settings
        let iotDataConfiguration = AWSServiceConfiguration(region: .USWest2,     // Use AWS typedef .Region
                                                           endpoint: iotEndPoint,
                                                           credentialsProvider: credentials)  // credentials is the same var as created above
            
        AWSIoTDataManager.register(with: iotDataConfiguration!, forKey: "kDataManager")

        // Access the AWSDataManager instance as follows:

        
        dataManager = AWSIoTDataManager(forKey: "kDataManager")

        
        self.getAWSClientID { clientId, error in
            self.connectToAWSIoT(clientId: clientId)
            
        }
        
                
    }

    
    
    //   -----------------to get ClientID-----------------
    
    func getAWSClientID(completion: @escaping (_ clientId: String?,_ error: Error? ) -> Void) {
            // Depending on your scope you may still have access to the original credentials var
        
// THis is team's Credential
        let credentials = AWSCognitoCredentialsProvider(regionType:.USWest2, identityPoolId: "us-west-2:0ec8bfb0-1ce6-4499-82b3-a1658fd6ee76")
        
            credentials.getIdentityId().continueWith(block: { (task:AWSTask<NSString>) -> Any? in
                if let error = task.error as NSError? {
                    print("Failed to get client ID => \(error)")
                    completion(nil, error)
                    return nil  // Required by AWSTask closure
                }
                
                let clientId = task.result! as String
                print("Got client ID => \(clientId)")
                completion(clientId, nil)
                return nil // Required by AWSTask closure
            })
        }
    
    
    // connect to AWS IoT via clientID
    func connectToAWSIoT(clientId: String!) {
   
            
            func mqttEventCallback(_ status: AWSIoTMQTTStatus ) {
   
         
                switch status {
                case .connecting: print("Connecting to AWS IoT")
                case .connected:
                    print("Connected to AWS IoT")
                    // Register subscriptions here
                    self.registerSubscriptions()
                       
                case .connectionError: print("AWS IoT connection error")
                case .connectionRefused: print("AWS IoT connection refused")
                case .protocolError: print("AWS IoT protocol error")
                case .disconnected: print("AWS IoT disconnected")
                case .unknown: print("AWS IoT unknown state")
                default: print("Error - unknown MQTT state")
                }
            }
            // Ensure connection gets performed background thread (so as not to block the UI)
            DispatchQueue.global(qos: .background).async {
                do {
                    print("Attempting to connect to IoT device gateway with ID = \(clientId)")
                    let dataManager = AWSIoTDataManager(forKey: "kDataManager")
                    dataManager.connectUsingWebSocket(withClientId: clientId,
                                                      cleanSession: true,
                                                      statusCallback: mqttEventCallback)
                } catch {
                //    print("Error, failed to connect to device gateway => \(error!)")
                    print("Error, failed to connect to device gateway => \(error)")
                }
            }
        }
    
    func registerSubscriptions() {
        
            func messageReceived(payload: Data) {
                let payloadDictionary = jsonDataToDict(jsonData: payload)
                print("Message received: \(payloadDictionary)")
                
                let decodedData = parse(jsonData: payload)
                
                // Ensure LineChartView gets performed background thread (so as not to block the UI)
                DispatchQueue.main.async {
                    // UIView usage
                    if(decodedData!.Room == "Garage"){
                        self.view.addSubview(self.lineChartView)
                        self.lineChartView.centerInSuperview()
                        self.lineChartView.width(to: self.view)
                        self.lineChartView.heightToWidth(of: self.view)
                        self.setData(et: decodedData!)
                        
                        
                        // Update Current Time & Moisture Label
                        let timezoneOffset =  TimeZone.current.secondsFromGMT()
                        let epochTime = TimeInterval(decodedData!.Time!)
                        let timezoneEpochOffset = (epochTime + Double(timezoneOffset))
                        let date = Date(timeIntervalSince1970: timezoneEpochOffset)
                        
                        
                        self.timeLabel.text = "Time: \(date)"
                        self.moistureLabel.text = "Moisture: \(decodedData!.moistureString)"
                        self.roomLabel.text = decodedData!.Room
                    }
                }
               
            }
                
                // Handle message event here...

        // Team-Bedroom topic
 //           let topicArray = ["Bedroom/pub"]
   
        let topicArray = ["esp32/pub"]
        let dataManager = AWSIoTDataManager(forKey: "kDataManager")
        
        for topic in topicArray {
            print("Registering subscription to => \(topic)")
            dataManager.subscribe(toTopic: topic,
                                  qoS: .messageDeliveryAttemptedAtLeastOnce,  // Set according to use case
                                  messageCallback: messageReceived)
        }
        
        
        
        
    }

    func jsonDataToDict(jsonData: Data?) -> Dictionary <String, Any> {
            // Converts data to dictionary or nil if error
            do {
                let jsonDict = try JSONSerialization.jsonObject(with: jsonData!, options: [])
                let convertedDict = jsonDict as! [String: Any]
                return convertedDict
            } catch {
                // Couldn't get JSON
                print(error.localizedDescription)
                return [:]
            }
    }
    
    func publishMessage(message: String!, topic: String!) {
      let dataManager = AWSIoTDataManager(forKey: "kDataManager")
      dataManager.publishString(message, onTopic: topic, qoS: .messageDeliveryAttemptedAtLeastOnce) // Set QoS as needed
        print("publish message into the IoT Core")
    }
    
    
    
    private func readLocalFile(forName name: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: name, ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                print(jsonData)
                return jsonData
            }
        } catch {
            print(error)
        }
        
        return nil
    }
    
    
    

    private func parse(jsonData: Data) -> CData? {
        do {
            print("BEFOR PARSEING")
            let decodedData = try JSONDecoder().decode(CData.self,
                                                       from: jsonData)
            print("After PARSING")
            print(decodedData)
            print("Time IS: ")
            print(decodedData.Time!)
            print("Moisture IS: ")
            print(decodedData.Moisture!)
            return decodedData
        } catch {
            print("decode error!!!!!!")
            return nil
        }
    }

    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        print(entry)
    }

    // func setData(et: CData, yV: inout [ChartDataEntry]){
    func setData(et: CData){
            // The dataEntry format is: ChartDataEntry(x: 0.0, y:10.0),

            if (et.Moisture != nil){
                
                var calendar = Calendar.current
                
                // Modify the time
                let epochTime = TimeInterval(et.Time!)
                
                let date = Date(timeIntervalSince1970: epochTime)
                
                let hour = calendar.component(.hour, from: date)
                let minute = calendar.component(.minute, from: date)
                let second = calendar.component(.second, from: date)
                
                let time = hour*10000 + minute*100 + second

                print("TIME IS: \(time) ")
                
                print("&&&& Hour: \(hour) Minute: \(minute) Second: \(second)")
                
                var wd = ChartDataEntry(x: Double(time), y: et.Moisture!)
                print("### Check ### Check ### \(yValues)")
                yValues.append(wd)
                print("@@@@ Check @@@@ Check @@@@ \(yValues)")
                
            }
        
        // create a label under the chart
        let set1 = LineChartDataSet(entries: yValues, label: "Time-Moisture read from M5Stack")

        set1.mode = .cubicBezier
        set1.drawCirclesEnabled = false
        set1.lineWidth = 3
        set1.setColor(.white)
        
        set1.drawHorizontalHighlightIndicatorEnabled = false
        set1.highlightColor = .systemRed
        
        let data = LineChartData(dataSet: set1)
        
        data.setDrawValues(false)
        
        lineChartView.data = data
    }


}
